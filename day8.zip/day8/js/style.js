function alertjs1(){
	document.body.style.backgroundColor="lightblue";
	alert('your backgroundColor will change in to lightblue');
	document.getElementById('exb1').style.backgroundColor="blue";
}

function promptjs1(){
	prompt('your fontSize will change')
	document.body.style.fontSize="20px";
}

function confirmjs1(){
	confirm('your fontFamily will change')
	document.body.style.fontFamily="cursive";
	document.getElementById('exb1').style.backgroundColor=prompt('enter your color');
}

function externalonchange(){
	document.body.style.backgroundColor=document.getElementById('cb1').value;
}

function externalonchange1(){
	document.getElementById('d1').style.backgroundColor=document.getElementById('cb2').value;
}

function abc(){
	var name = prompt('enter your name');
	document.getElementById('b2').innerHTML=name;
}

function join(){
	var f=document.getElementById('t1').value;
	var l=document.getElementById('t2').value;

	document.getElementById('here').innerHTML=f+l;

}
console.log('hiii');

