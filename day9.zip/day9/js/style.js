function focus(){
	document.getElementById('d1').src="../img/img1.jpg";
}